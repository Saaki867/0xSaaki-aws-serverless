// Import du SDK AWS
const AWS = require('aws-sdk');
const { v4: uuidv4 } = require('uuid');

// Initialisation du client DynamoDB
const dynamoDB = new AWS.DynamoDB.DocumentClient();

// Nom de la table défini dans les variables d'environnement
const TABLE_NAME = process.env.TABLE_NAME;

exports.handler = async (event) => {
    console.log('Received event:', JSON.stringify(event, null, 2));
    
    // Pour les requêtes OPTIONS (CORS preflight)
    if (event.httpMethod === 'OPTIONS') {
        return {
            statusCode: 200,
            headers: {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
                'Access-Control-Allow-Methods': 'OPTIONS,POST,GET'
            },
            body: JSON.stringify({})
        };
    }
    
    try {
        // Parsing du corps de la requête
        let requestBody;
        try {
            requestBody = JSON.parse(event.body);
            console.log('Parsed request body:', requestBody);
        } catch (parseError) {
            console.error('Error parsing request body:', parseError);
            return {
                statusCode: 400,
                headers: {
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Headers': 'Content-Type',
                    'Access-Control-Allow-Methods': 'OPTIONS,POST,GET',
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ 
                    message: 'Erreur de parsing du JSON', 
                    error: parseError.message,
                    body: event.body
                })
            };
        }
        
        // Validation des données
        if (!requestBody.title || !requestBody.content) {
            return {
                statusCode: 400,
                headers: {
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Headers': 'Content-Type',
                    'Access-Control-Allow-Methods': 'OPTIONS,POST,GET',
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ 
                    message: 'Le titre et le contenu sont requis',
                    requestBody
                })
            };
        }
        
        // Création de l'entrée avec un ID unique
        const item = {
            id: uuidv4(), // Génération d'un ID unique
            title: requestBody.title,
            content: requestBody.content,
            createdAt: new Date().toISOString()
        };
        
        console.log('Item to insert:', item);
        
        // Paramètres pour la requête put
        const params = {
            TableName: TABLE_NAME,
            Item: item
        };
        
        // Ajout de l'item dans DynamoDB
        await dynamoDB.put(params).promise();
        
        // Réponse de succès
        return {
            statusCode: 201,
            headers: {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': 'Content-Type',
                'Access-Control-Allow-Methods': 'OPTIONS,POST,GET',
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ 
                message: 'Données ajoutées avec succès', 
                item 
            })
        };
    } catch (error) {
        console.error('Error:', error);
        
        // Réponse en cas d'erreur
        return {
            statusCode: 500,
            headers: {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': 'Content-Type',
                'Access-Control-Allow-Methods': 'OPTIONS,POST,GET',
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ 
                message: 'Erreur lors de l\'ajout des données', 
                error: error.message 
            })
        };
    }
};
